﻿using Azure.Core;
using CA_Notes.Domain.Entities;
using CA_Notes.Domain.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace CA_Notes.Domain.Services
{

    public class ClasseService : IClasseRepository
    {
        private readonly string _connectionString;
        private CA_Notes.Infrastructure.ESP _spAccessor;

        public ClasseService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _spAccessor = new Infrastructure.ESP(_connectionString);
        }

        public ClasseEntity Add(ClasseEntity classe)
        {
            try
            {
                SqlParameter pNom = new SqlParameter("Nom", classe.Nom);
                SqlParameter pNiveau = new SqlParameter("Niveau", classe.Niveau);

                SqlParameter[] addParams = new SqlParameter[] { pNom, pNiveau };

                DataTable dt = _spAccessor.ExecuteStoredProcedure("AjouterClasse", addParams);

                if (dt != null && dt.Rows.Count == 1)
                {
                    ClasseEntity result = new ClasseEntity();
                    result = classe;
                    result.Id = (int)dt.Rows[0]["Id"];
                    return result;
                }

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return new ClasseEntity();

        }

        public ClasseEntity Edit(ClasseEntity classe)
        {
            SqlParameter pId = new SqlParameter("Id", classe.Id);
            SqlParameter pNom = new SqlParameter("Nom", classe.Nom);
            SqlParameter pNiveau = new SqlParameter("Niveau", classe.Niveau);

            try
            {
                SqlParameter[] setParams = new SqlParameter[] { pId, pNom, pNiveau };

                DataTable dtEdit = _spAccessor.ExecuteStoredProcedure("ModifierClasse", setParams);
                if (dtEdit != null && dtEdit.Rows.Count == 1)
                {
                    ClasseEntity result = new ClasseEntity();
                    result.Id = (int)dtEdit.Rows[0]["Id"];
                    result.Nom = dtEdit.Rows[0]["Nom"].ToString();
                    result.Niveau = dtEdit.Rows[0]["Niveau"].ToString();
                    return result;
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return new ClasseEntity();
        }

        public bool Delete(ClasseEntity classe)
        {
            SqlParameter pId = new SqlParameter("Id", classe.Id);
            SqlParameter pNom = new SqlParameter("Nom", classe.Nom);
            SqlParameter pNiveau = new SqlParameter("Niveau", classe.Niveau);

            try
            {

                SqlParameter[] deleteParam = new SqlParameter[] { pId };

                DataTable dtDelete = _spAccessor.ExecuteStoredProcedure("SupprimerClasse", deleteParam);
                if (dtDelete != null && dtDelete.Rows.Count == 1)
                {
                    bool result = (bool)dtDelete.Rows[0]["Result"];
                    return result;
                }
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return false;
        }

        public IEnumerable<ClasseEntity> ListAll()
        {
            List<ClasseEntity> result = new List<ClasseEntity>();
            try
            {
                result.Add(new ClasseEntity(1, "TEST", "TEST"));
                /*DataTable dt = _spAccessor.ExecuteStoredProcedure("AfficherClasses", null);

                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        ClasseEntity classeEntity = new ClasseEntity((int)dr["Id"], dr["Name"].ToString(), dr["Niveau"].ToString());
                        result.Add(classeEntity);
                    }

                }*/

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return result;
        }

        public ClasseEntity ListClasse(int id)
        {
            //SqlParameter pId = new SqlParameter("Id", id);

            try
            {
                return new ClasseEntity(1, "TEST", "TEST");
                /*var allClasses = this.ListAll();
                if (allClasses.Count() > 0 && allClasses.Where(x => x.Id == id).Count() > 0)
                {
                    return allClasses.Where(x => x.Id == id).FirstOrDefault();
                }*/
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return new ClasseEntity();
        }
    }

}
