﻿namespace CA_Notes.Domain.Entities
{
    public class ClasseEntity
    {
        public ClasseEntity()
        {
            this.Id = 0;
            this.Nom = "";
            this.Niveau = "";
        }

        public ClasseEntity(int id, string nom, string niveau)
        {
            this.Id = id;
            this.Nom = nom;
            this.Niveau = niveau;
        }

        public int Id { get; set; }
        public string Nom { get; set; }
        public string Niveau { get; set; }
    }
}
