﻿using CA_Notes.Domain.Services;
using Microsoft.Extensions.Configuration;

namespace CA_Notes.Application.DTOs
{
    public class ClasseDto
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Niveau { get; set; }

        public List<ClasseDto> GetAllClasses(IConfiguration cnf)
        {
            List<ClasseDto> result = new List<ClasseDto>();
            try
            {
                ClasseService svc = new ClasseService(cnf);
                var listAll = svc.ListAll();
                foreach (var current in listAll) {
                    var classeDto = new ClasseDto();
                    classeDto.Id = current.Id;
                    classeDto.Nom = current.Nom;
                    classeDto.Niveau = current.Niveau;
                    result.Add(classeDto);
                }

            }
            catch (Exception ex){ Console.WriteLine(ex.Message);  }

            return result;
        }

        public ClasseDto GetOneClasse(IConfiguration cnf, int id)
        {
            ClasseDto result = new ClasseDto();
            try
            {
                ClasseService svc = new ClasseService(cnf);
                var listone = svc.ListClasse(id);
                result.Id = listone.Id;
                result.Nom = listone.Nom;
                result.Niveau = listone.Niveau;
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

            return result;

        }
    }
}
